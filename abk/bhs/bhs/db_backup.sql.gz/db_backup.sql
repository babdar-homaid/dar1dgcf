# Snfoor 3.4  (http://www.magtrb.com)
# mySQL backup (February 8, 2018 7:53 pm)   Type = Complete

CREATE TABLE `Admin` (
  `id` int(11) NULL auto_increment,
  `name` varchar(100) NULL,
  `Password` varchar(250) NULL,
  `cp` int(11) NULL,
  `cpanel` int(11) NULL default '2',
  PRIMARY KEY (`id`)
) TYPE=InnoDB AUTO_INCREMENT=27;

CREATE TABLE `D_sector` (
  `id` int(11) NULL auto_increment,
  `name` varchar(200) NULL,
  PRIMARY KEY (`id`)
) TYPE=MyISAM AUTO_INCREMENT=24;

CREATE TABLE `D_sub` (
  `id` int(11) NULL auto_increment,
  `name` varchar(200) NULL,
  `sector` varchar(200) NULL,
  PRIMARY KEY (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE `Sector` (
  `id` int(11) NULL auto_increment,
  `name` varchar(100) NULL,
  PRIMARY KEY (`id`)
) TYPE=MyISAM AUTO_INCREMENT=16;

CREATE TABLE `Visit` (
  `id` int(11) NULL auto_increment,
  `name_t` varchar(50) NULL,
  `card_m` varchar(50) NULL,
  `name_s` varchar(50) NULL,
  `name_z` varchar(10) NULL,
  `Type` varchar(10) NULL,
  `school` varchar(50) NULL,
  `mosque` varchar(50) NULL,
  `Sector` varchar(50) NULL,
  `date_1` varchar(50) NULL,
  `date_2` varchar(50) NULL,
  `date_3` varchar(50) NULL,
  `yom` varchar(50) NULL,
  `class_1` varchar(50) NULL,
  `class_2` varchar(50) NULL,
  `class_3` varchar(50) NULL,
  `class_4` varchar(50) NULL,
  `class_5` varchar(50) NULL,
  `class_6` varchar(50) NULL,
  `class_7` varchar(50) NULL,
  `class_8` varchar(50) NULL,
  `class_9` varchar(50) NULL,
  `class_10` varchar(50) NULL,
  `class_11` varchar(50) NULL,
  `class_12` varchar(50) NULL,
  `class_13` varchar(50) NULL,
  `class_14` varchar(50) NULL,
  `class_15` varchar(50) NULL,
  `class_16` varchar(50) NULL,
  `class_171` varchar(50) NULL,
  PRIMARY KEY (`id`)
) TYPE=MyISAM AUTO_INCREMENT=55;

CREATE TABLE `reports1` (
  `id` int(11) NULL auto_increment,
  `xd` varchar(50) NULL default '1',
  `text1` longtext NULL,
  `Number` varchar(250) NULL,
  `D_sector` varchar(250) NULL,
  `Thread` varchar(250) NULL,
  `Transfer` varchar(250) NULL,
  `What` varchar(250) NULL,
  `admin` varchar(100) NULL,
  `date1` date NULL,
  `daten` varchar(100) NULL,
  `dateR` varchar(100) NULL,
  `datee` varchar(100) NULL,
  `Today` varchar(10) NULL,
  PRIMARY KEY (`id`)
) TYPE=MyISAM AUTO_INCREMENT=81;

CREATE TABLE `soor` (
  `id` int(11) NULL auto_increment,
  `name` varchar(100) NULL,
  `nm` varchar(50) NULL,
  `ayat` varchar(50) NULL,
  PRIMARY KEY (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1;


# dumping data for bndri_mo.Admin
INSERT INTO `Admin` (`id`, `name`, `Password`, `cp`, `cpanel`) VALUES (14, 'محمد', 'bdd8817990ef209f0fb6b049f2d2ea0c', 6, 2);
INSERT INTO `Admin` (`id`, `name`, `Password`, `cp`, `cpanel`) VALUES (16, 'بندر', 'bdd8817990ef209f0fb6b049f2d2ea0c', 7, 2);
INSERT INTO `Admin` (`id`, `name`, `Password`, `cp`, `cpanel`) VALUES (21, 'عمر بن فؤاد خياط', '55ea562592a62acdea4431eb1a7ddbc3', 6, 2);
INSERT INTO `Admin` (`id`, `name`, `Password`, `cp`, `cpanel`) VALUES (24, 'مدير وحدة المتابعة', '55ea562592a62acdea4431eb1a7ddbc3', 7, 2);
INSERT INTO `Admin` (`id`, `name`, `Password`, `cp`, `cpanel`) VALUES (25, 'مدير المكتب', 'e10adc3949ba59abbe56e057f20f883e', 7, 2);
INSERT INTO `Admin` (`id`, `name`, `Password`, `cp`, `cpanel`) VALUES (26, 'سعادة وكيل الجامعة للتطوير', 'e10adc3949ba59abbe56e057f20f883e', 6, 2);


# dumping data for bndri_mo.D_sector
INSERT INTO `D_sector` (`id`, `name`) VALUES (9, 'عمادة شؤون المكتبات');
INSERT INTO `D_sector` (`id`, `name`) VALUES (10, 'عمادة التعلم الإلكتروني والتعليم عن بعد');
INSERT INTO `D_sector` (`id`, `name`) VALUES (11, 'عمادة القبول والتسجيل');
INSERT INTO `D_sector` (`id`, `name`) VALUES (12, 'مركز تطوير التعليم الجامعي ');
INSERT INTO `D_sector` (`id`, `name`) VALUES (13, 'مركز الحوسبة العالية الآداء');
INSERT INTO `D_sector` (`id`, `name`) VALUES (14, 'مركز الارشاد المهني والدعم الوظيفي');
INSERT INTO `D_sector` (`id`, `name`) VALUES (15, 'إدارة الإعتماد الأكاديمي');
INSERT INTO `D_sector` (`id`, `name`) VALUES (16, 'إدارة التخطيط الإستراتيجي');
INSERT INTO `D_sector` (`id`, `name`) VALUES (17, 'إدارة العلاقات الثقافية');
INSERT INTO `D_sector` (`id`, `name`) VALUES (18, 'إدارة الجودة');
INSERT INTO `D_sector` (`id`, `name`) VALUES (19, 'الإدارة العامة للمتاحف');
INSERT INTO `D_sector` (`id`, `name`) VALUES (20, 'إدارة القياس والتقويم');
INSERT INTO `D_sector` (`id`, `name`) VALUES (21, 'مرصد الدراسات الويب');
INSERT INTO `D_sector` (`id`, `name`) VALUES (22, 'مدير العلاقات العامة والإعلام');
INSERT INTO `D_sector` (`id`, `name`) VALUES (23, 'مكتب معالي مدير الجامعة');




# dumping data for bndri_mo.Sector
INSERT INTO `Sector` (`id`, `name`) VALUES (15, '1438');
INSERT INTO `Sector` (`id`, `name`) VALUES (11, '1438');


# dumping data for bndri_mo.Visit
INSERT INTO `Visit` (`id`, `name_t`, `card_m`, `name_s`, `name_z`, `Type`, `school`, `mosque`, `Sector`, `date_1`, `date_2`, `date_3`, `yom`, `class_1`, `class_2`, `class_3`, `class_4`, `class_5`, `class_6`, `class_7`, `class_8`, `class_9`, `class_10`, `class_11`, `class_12`, `class_13`, `class_14`, `class_15`, `class_16`, `class_171`) VALUES (50, 'أحمد حسن طلبة جمعة', '3029891462', 'ممدوح', '', '1', 'الإمام ابن كثير المكي', 'الفرقان', 'مكتب اشراف غمقية', '1434', '1', '1', 'السبت', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `Visit` (`id`, `name_t`, `card_m`, `name_s`, `name_z`, `Type`, `school`, `mosque`, `Sector`, `date_1`, `date_2`, `date_3`, `yom`, `class_1`, `class_2`, `class_3`, `class_4`, `class_5`, `class_6`, `class_7`, `class_8`, `class_9`, `class_10`, `class_11`, `class_12`, `class_13`, `class_14`, `class_15`, `class_16`, `class_171`) VALUES (51, 'خديجة عيظه الجبيري', '1049915273', 'عقيل', '', '2', 'على ضفاف المجد ', 'حارة الثمانية', 'مكتب اشراف غمقية', '1438', '1', '1', 'السبت', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `Visit` (`id`, `name_t`, `card_m`, `name_s`, `name_z`, `Type`, `school`, `mosque`, `Sector`, `date_1`, `date_2`, `date_3`, `yom`, `class_1`, `class_2`, `class_3`, `class_4`, `class_5`, `class_6`, `class_7`, `class_8`, `class_9`, `class_10`, `class_11`, `class_12`, `class_13`, `class_14`, `class_15`, `class_16`, `class_171`) VALUES (52, 'هيف علي بلقاسم البركاتي', '10169111310', 'ام راكان', 'مقبول', '2', 'أضواء البيان', 'صهدة', 'قطاع الجنوب', '1438', '1', '25', 'الأربعاء', '7', '6', '5', '4', '5', '4', '3', '4', '10', '7', '8', '10', '6', '4', '6', '89', '');
INSERT INTO `Visit` (`id`, `name_t`, `card_m`, `name_s`, `name_z`, `Type`, `school`, `mosque`, `Sector`, `date_1`, `date_2`, `date_3`, `yom`, `class_1`, `class_2`, `class_3`, `class_4`, `class_5`, `class_6`, `class_7`, `class_8`, `class_9`, `class_10`, `class_11`, `class_12`, `class_13`, `class_14`, `class_15`, `class_16`, `class_171`) VALUES (53, 'هيف علي بلقاسم البركاتي', '10169111310', 'ام راكان', '', '2', 'أضواء البيان', 'صهدة', 'قطاع الجنوب', '1438', '1', '26', 'الخميس', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `Visit` (`id`, `name_t`, `card_m`, `name_s`, `name_z`, `Type`, `school`, `mosque`, `Sector`, `date_1`, `date_2`, `date_3`, `yom`, `class_1`, `class_2`, `class_3`, `class_4`, `class_5`, `class_6`, `class_7`, `class_8`, `class_9`, `class_10`, `class_11`, `class_12`, `class_13`, `class_14`, `class_15`, `class_16`, `class_171`) VALUES (54, 'تميم ادم عثمان بكر', '2062981689', 'اشراف الجنوب', 'تجربة', '1', 'جندب بن عبدالله الازدي', 'ابو الزور', 'قطاع الجنوب', '1438', '3', '20', 'الاثنين', '8', '6', '6', '5', '4', '3', '3', '2', '1', '8', '10', '10', '11', '4', '6', '87', '');


# dumping data for bndri_mo.reports1
INSERT INTO `reports1` (`id`, `xd`, `text1`, `Number`, `D_sector`, `Thread`, `Transfer`, `What`, `admin`, `date1`, `daten`, `dateR`, `datee`, `Today`) VALUES (73, 'لم يتم الرد', 'text1', '', 'عمادة شؤون المكتبات', '15265', '', '', 'مدير وحدة المتابعة', NULL, '2017-3-1', '1438/5/29', '1438/6/3', '');
INSERT INTO `reports1` (`id`, `xd`, `text1`, `Number`, `D_sector`, `Thread`, `Transfer`, `What`, `admin`, `date1`, `daten`, `dateR`, `datee`, `Today`) VALUES (78, 'لم يتم الرد', 'text1', '', 'عمادة التعلم الإلكتروني والتعليم عن بعد', '48923', '', '', 'مدير وحدة المتابعة', NULL, '2017-3-4', '1438/5/29', '1438/6/6', '');
INSERT INTO `reports1` (`id`, `xd`, `text1`, `Number`, `D_sector`, `Thread`, `Transfer`, `What`, `admin`, `date1`, `daten`, `dateR`, `datee`, `Today`) VALUES (75, 'تم الرد', 'text1', '', 'مركز تطوير التعليم الجامعي ', '15749', '', '  المتابعة يوم 15/6', 'مدير وحدة المتابعة', NULL, '2017-4-16', '1438/5/30', '1438/7/20', '');
INSERT INTO `reports1` (`id`, `xd`, `text1`, `Number`, `D_sector`, `Thread`, `Transfer`, `What`, `admin`, `date1`, `daten`, `dateR`, `datee`, `Today`) VALUES (77, 'لم يتم الرد', 'text1', '', 'عمادة القبول والتسجيل', '48923', '', '', 'مدير وحدة المتابعة', NULL, '2017-3-4', '1438/5/29', '1438/6/6', '');
INSERT INTO `reports1` (`id`, `xd`, `text1`, `Number`, `D_sector`, `Thread`, `Transfer`, `What`, `admin`, `date1`, `daten`, `dateR`, `datee`, `Today`) VALUES (79, 'تم الرد', 'text1', '', 'عمادة شؤون المكتبات', '99999', '', '', 'مدير المكتب', NULL, '2017-4-3', '1438/7/1', '1438/7/7', '');




